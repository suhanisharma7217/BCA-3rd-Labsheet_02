# Sample Outputs — BCA201P Lab Sheet-02

These are illustrative sample runs. Prompts and output formatting may appear on the same line when entered in a terminal. Q29 output varies because it uses random numbers.

## Q01_TriangleArea

```text
Enter the three sides: Area of triangle = 6.00
```

## Q02_CompoundInterest

```text
Enter principal, annual rate (%), and time (years): Compound interest = 102.50
Final amount = 1102.50
```

## Q03_DistanceBetweenPoints

```text
Enter x1, y1, x2, y2: Distance = 5.00
```

## Q04_VisitorCounter

```text
Initial visitors: 0
Visitor enters (prefix ++): 1
Visitor enters (postfix ++): 1
Visitors after entry: 2
Visitor leaves (prefix --): 1
Visitor leaves (postfix --): 1
Visitors after leaving: 0
```

## Q05_NegativeValue

```text
Enter an integer: Negative value = -8
```

## Q06_HalvingSteps

```text
Enter a positive number: Steps until number is less than 1 = 5
```

## Q07_WeeklyRainfall

```text
Enter rainfall for day 1: Enter rainfall for day 2: Enter rainfall for day 3: Enter rainfall for day 4: Enter rainfall for day 5: Enter rainfall for day 6: Enter rainfall for day 7: Total rainfall for 7 days = 28.00
```

## Q08_ValidTriangleAngles

```text
Enter three angles: The angles form a valid triangle.
```

## Q09_LexicographicStrings

```text
Enter the first string: Enter the second string: First string comes before second string.
```

## Q10_LeapYearRange

```text
Enter year, range start, and range end: 2024 is a leap year and is within the range.
```

## Q11_StudentPass

```text
Enter theory, practical, and overall percentages: Student passes the course.
```

## Q12_SmallestOfFour

```text
Enter four integers: Smallest number = 2
```

## Q13_CharacterType

```text
Enter one character: Character is a vowel.
```

## Q14_XorSwap

```text
Enter two integers: Before swap: a = 10, b = 20
After swap:  a = 20, b = 10
```

## Q15_CountSetBits

```text
Enter an integer: Number of set bits = 3
```

## Q16_ShiftMultiplyDivide

```text
Enter an integer and a shift amount (0-30): Multiply by 2^3 = 40
Divide by 2^3 = 0
```

## Q17_RotateBitsLeft

```text
Enter an integer: After rotating bits left by 2 = 4
Binary result =                                100
```

## Q18_Fibonacci20

```text
First 20 Fibonacci terms:
0 1 1 2 3 5 8 13 21 34 55 89 144 233 377 610 987 1597 2584 4181
```

## Q19_ArmstrongNumbers

```text
Armstrong numbers from 1 to 1000:
1 2 3 4 5 6 7 8 9 153 370 371 407
```

## Q20_PasswordDoWhile

```text
Enter password: Incorrect password. Try again.
Enter password: Access granted.
```

## Q21_FactorsDoWhile

```text
Enter a positive integer: Factors: 1 2 3 4 6 12
```

## Q22_ReverseDigits

```text
Enter an integer: Reversed number = 4321
```

## Q23_NumberPalindrome

```text
Enter an integer: The number is a palindrome.
```

## Q24_ArrayMinMax

```text
Array: 42, 7, 19, 83, -4, 26
Minimum = -4
Maximum = 83
```

## Q25_AverageMarks2D

```text
Average of all marks = 81.55555555555556
```

## Q26_WeekdayWeekend

```text
Enter day number (1=Monday, 7=Sunday): Weekend
```

## Q27_GradeMeaning

```text
Enter grade (A-F): Excellent
```

## Q28_SkipPerfectSquares

```text
Numbers from 1 to 50 excluding perfect squares:
2 3 5 6 7 8 10 11 12 13 14 15 17 18 19 20 21 22 23 24 26 27 28 29 30 31 32 33 34 35 37 38 39 40 41 42 43 44 45 46 47 48 50
```

## Q29_RandomUntil91

```text
Sample output varies because the numbers are random. The loop stops when 91 is generated.
```

## Q30_MixedAdvanced

```text
Enter a positive integer: 4 is a power of 4.
After toggling the 3rd bit = 0
Multiplication table (skip multiples of 6; stop at multiples of 48):
4 x 1 = 4
4 x 2 = 8
4 x 4 = 16
4 x 5 = 20
4 x 7 = 28
4 x 8 = 32
4 x 10 = 40
4 x 11 = 44
```
