# BCA201P — Java Lab Sheet 02 Solutions

**Course:** Foundations of Java Development  
**Semester:** BCA III Semester (Session 2026–2027)  
**Language:** Java  
**Recommended JDK:** 21 or higher

This repository contains solutions to all 30 questions from the uploaded BCA201P Lab Sheet-02, with source code and illustrative sample outputs.

## Contents

- `Q01_TriangleArea.java` through `Q30_MixedAdvanced.java` — one standalone Java program per question.
- `SAMPLE_OUTPUTS.md` — sample output for each program.
- `README.md` — project overview and instructions.

## How to compile and run

Install JDK 21 or later. Open a terminal in this folder and compile/run one program at a time. For example:

```bash
javac Q01_TriangleArea.java
java Q01_TriangleArea
```

Replace `Q01_TriangleArea` with the class name of the question you want to run. Most programs request input in the terminal. Q20 uses the demonstration password `java123`; change it in the source if your instructor specifies a different one.

## Notes

- Sample outputs use example inputs and are provided for reference; your output will differ when you enter different values.
- Q29 uses random numbers, so its output varies each run.
- Q25 calculates the average of all values in the 2D marks array.
- Q26 uses `1 = Monday` through `7 = Sunday`.
- Q11 follows the stated rule: theory at least 40% **and** practical at least 50%, **or** overall at least 50%.

## Questions covered

1. Area of a triangle using Heron's formula
2. Compound interest
3. Distance between two points
4. Prefix/postfix increment and decrement visitor counter
5. Unary minus
6. Repeated halving with `/=`
7. Weekly rainfall using `+=`
8. Triangle angle validation
9. Lexicographic string comparison using character relational operators
10. Leap year within a range
11. Course pass conditions using logical operators
12. Smallest of four numbers using nested ternary operators
13. Character classification using ternary operator
14. Swap using XOR
15. Count set bits
16. Multiplication/division using shift operators
17. Rotate integer bits left by two positions
18. First 20 Fibonacci terms
19. Armstrong numbers from 1 to 1000
20. Password retry with `do-while`
21. Factors using `do-while`
22. Reverse digits using `while`
23. Palindrome check using `while`
24. Array minimum and maximum using for-each
25. Average marks in a 2D array using for-each
26. Weekday/weekend using switch
27. Grade meaning using switch
28. Skip perfect squares using `continue`
29. Random numbers until divisible by both 7 and 13 using `break`
30. Combined shift, bitwise, for-loop, continue, and break exercise
