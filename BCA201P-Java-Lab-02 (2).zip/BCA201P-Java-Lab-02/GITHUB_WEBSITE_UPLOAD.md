# Uploading this project to GitHub using the website

1. Sign in at https://github.com/ and create a repository named `BCA201P-Java-Lab-02`.
2. Choose Public or Private according to your preference. You can initialize it with a README, or leave it empty.
3. Download and extract the ZIP file on your computer.
4. Open the repository on GitHub and choose **Add file → Upload files**.
5. Select all 33 files in the extracted folder (`README.md`, `SAMPLE_OUTPUTS.md`, and the 30 `.java` files) and drag them into the upload area. If you initialized the repository with a README, you may need to replace/overwrite it with this README or upload the remaining files first.
6. Enter a commit message such as `Add BCA201P Lab Sheet 02 Java solutions`.
7. Click **Commit changes**.

Tip: GitHub's web uploader is simplest when you upload the files from the extracted folder, not the ZIP itself. Uploading the ZIP alone will store it as an archive rather than displaying each source file.
